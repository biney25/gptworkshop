# ROOM / IQ

**An ESP32 smart-room mini project: light when needed, ventilation when hot.**

The complete Wokwi circuit, firmware and demo controls are included. You do not need physical hardware. The yellow LED represents a room lamp; a servo represents a vent flap. An OLED screen shows what the system is doing.

Open **[the visual guide](docs/start-here.html)** for file-copy buttons, the circuit overview and presentation notes. The guide works as a standalone downloaded HTML file. The four Wokwi files are also in `dist/room-iq-wokwi.zip` after running `python3 tools/package.py`.

## Start in Wokwi

1. Open **https://wokwi.com/projects/new/esp32** in a browser. Choose an Arduino/C++ ESP32 project if prompted.
2. Replace the contents of the **sketch.ino** tab with [sketch.ino](sketch.ino).
3. Open the **diagram.json** tab and replace its contents with [diagram.json](diagram.json). This creates and wires the entire circuit for you.
4. Use the editor's **+ / New file** control to create **room_controller.h** and paste [room_controller.h](room_controller.h). The filename must match exactly, including `.h`.
5. Create **libraries.txt** the same way and paste [libraries.txt](libraries.txt). Wokwi uses it to install the five libraries automatically. If that tab already exists, replace its contents.
6. Press the green **Play** button. The first build may take a little longer. Wait for `ROOM / IQ ready` in the Serial Monitor.
7. Click the blue **NEXT DEMO** button once for scenario 1, twice for scenario 2, and three times for scenario 3. A fourth press returns to **LIVE**. You can also press **D** while the circuit has keyboard focus.
8. Save the project in your Wokwi account to get a shareable project link. This repository does not contain a hosted Wokwi project URL.

The standard Wokwi web simulator handles the build. Arduino IDE, VS Code, a local compiler and a Wokwi CLI token are **not required** for these steps. If your Wokwi editor does not offer a new-file control, use its command palette (F1) and search for “new file.”

## Your three scenarios

| Demo button | Inputs used by the controller | Lamp | Vent | What to show |
|---|---|---|---|---|
| Press 1 — DEMO 1 | Dark: 20 lux; motion present; 24°C | ON | SHUT, 0° | Yellow LED lights; OLED says ON and SHUT |
| Press 2 — DEMO 2 | Bright: 800 lux; motion present; 32°C | OFF | OPEN, 90° | LED turns off; servo moves; OLED says OPEN |
| Press 3 — DEMO 3 | Dark: 20 lux; 24°C; motion for 1.5 s, then none | ON during hold, then OFF | SHUT, 0° | OLED counts down 10 s after motion ends; LED goes off |

In demo 3, the lamp switches off approximately **11.5 seconds after selecting the demo**: 1.5 seconds of motion plus a 10-second hold. It stays off until you change mode or restart the demo.

**Demo modes supply sample sensor readings to the real control rules; they do not force the outputs.** The sensor graphics/slider values do not move to match these sample readings. The OLED and Serial Monitor show the readings actually being used. Use LIVE to exercise the wired sensors themselves.

You may also type `1`, `2`, `3`, or `L` into the Wokwi Serial Monitor and send it. `3` restarts the timeout demo even if it is already selected. `L` selects LIVE; `?` prints the available commands. Keyboard **D** controls the diagram button; serial commands must be sent through the Serial Monitor.

## Try the actual sensors in LIVE

Select LIVE with the fourth button press or send `L`. The initial diagram has **24°C** and **20 lux**, but starts with **no motion**, so the lamp correctly stays off.

1. Click the **PIR motion sensor**, then **Simulate Motion**. The yellow lamp lights. The PIR stays high for 2 seconds; the firmware then holds the lamp for another 10 seconds. Trigger motion again to extend the hold.
2. Click the **photoresistor/LDR module** and increase its illumination to **800 lux**. The lamp turns off even during motion. Return to **20 lux** and trigger motion to turn it back on. The smoothing filter settles in roughly a second.
3. Click the **DHT22** and set temperature to **32°C**. Within the next 2-second sensor reading, the vent starts moving open. Change it to **24°C** and it shuts. The servo takes approximately 0.6 seconds to move between 0° and 90°.

The servo is the visible vent flap. This design does not include an exhaust fan or a room-temperature physics model: opening the servo does not automatically cool the simulated DHT22.

## How it makes decisions

```text
PIR motion ──> 10-second retriggerable occupancy timer ──┐
                                                       AND ──> Lamp LED
LDR light ──> darkness decision with hysteresis ─────────┘

DHT22 temperature ──> temperature hysteresis ──> Vent servo
                                  │
                       OLED + Serial Monitor
```

- **Lamp ON:** room is dark and motion is present or was detected within the last 10 seconds.
- **Lamp OFF:** room is bright, or no motion has been detected for 10 seconds after the PIR output goes low.
- **Light thresholds:** below **100 lux** enters DARK; **150 lux or above** exits DARK. Between them, retain the previous state.
- **Vent OPEN:** temperature is **28°C or above**. **Vent SHUT:** temperature is **26°C or below**. Between 26°C and 28°C, retain the previous position. At 24°C the vent shuts.
- **Ventilation works independently of motion and light**, so an empty hot room still ventilates.
- **Startup:** the lamp stays off until the first motion event. In a hysteresis band, initial states are light OFF and vent SHUT.

“Hysteresis” just means using different switch-on and switch-off thresholds. A reading wobbling around one value will not make the lamp flicker or the vent chatter.

## Components and wiring

| Component | Connection to ESP32 | Power / extra connections |
|---|---|---|
| ESP32 DevKit C V4 | Main controller | Wokwi virtual power; USB on a real board |
| LDR sensor module AO | GPIO 34, ADC1 | VCC → 3.3V; GND → GND; DO unused |
| PIR motion sensor OUT | GPIO 14 | VCC → 5V; GND → GND |
| DHT22 SDA/data | GPIO 4 | VCC → 3.3V; GND → GND; 10kΩ from data to 3.3V; NC unused |
| Yellow lamp LED | GPIO 25 → 330Ω → LED anode A | LED cathode C → GND |
| SG90-type vent servo PWM | GPIO 26 | V+ → 5V; GND → GND |
| SSD1306 128×64 I²C OLED | SDA → GPIO 21; SCL → GPIO 22 | VCC → 3.3V; GND → GND; address 0x3C |
| Demo pushbutton | Contact 1 → GPIO 27 | Contact 2 → GND; internal INPUT_PULLUP |

**Minimal physical shopping list:** one ESP32 board, one LDR module, one HC-SR501-style PIR, one DHT22, one SG90 servo, one I²C SSD1306 OLED, one LED, one 330Ω resistor, one 10kΩ resistor, one button, a breadboard and jumper wires. This is a small local automation project; it needs no Wi-Fi or cloud account during operation.

For a real prototype, use a regulated 5V supply with enough current for the servo and join its ground to ESP32 ground; do not power the servo from a GPIO or the 3.3V output. Keep the LDR module at **3.3V** so its analog output is safe for the ESP32. Calibrate the approximate lux thresholds on real hardware, and adjust servo endpoints to the physical flap. Keep the lamp as a low-voltage LED for the mini project; a mains lamp requires a separate properly rated switching design. A PIR senses movement rather than guaranteed human presence, so a still person can eventually time out.

## What makes it a stronger mini project

- One-button, repeatable demos plus a separate live-sensor mode.
- OLED with temperature, light level, lamp/vent icons and a shrinking countdown bar.
- Retriggerable timer with `millis()` instead of a blocking 10-second delay.
- Light smoothing and two sets of hysteresis thresholds.
- DHT22 sampled only once every 2 seconds; OLED refreshed at 5 Hz.
- Servo moves in 3° steps using hardware PWM; no additional servo library.
- No network dependency during operation and no per-loop dynamic string building.
- Debounced button, serial controls and unsigned timer arithmetic across clock rollover.
- Brief DHT failures reuse the last good reading. After 6 seconds without valid temperature, show SENSOR CHECK and open the vent. Invalid light input turns the lamp off. Normal readings restore normal operation.

These choices reduce unnecessary updates and switching. They do not constitute measured power savings: this prototype keeps the ESP32 awake so it can monitor sensors and update the display.

## Change the settings

Edit the constants at the top of **room_controller.h**:

```cpp
HOLD_MS = 10000;   // 10 seconds; use 60000 for 1 minute
DARK_LUX = 100;   // enter darkness below this
BRIGHT_LUX = 150; // exit darkness at/above this
OPEN_C = 28;      // vent opens at/above this
CLOSE_C = 26;     // vent closes at/below this
```

Keep `DARK_LUX < BRIGHT_LUX` and `CLOSE_C < OPEN_C`. The demo temperature and lux values also live in this header. The OLED progress bar follows `HOLD_MS` automatically. Servo endpoints and all GPIO assignments are at the top of **sketch.ino**.

## If something looks wrong

| Symptom | Fix |
|---|---|
| `room_controller.h: No such file or directory` | Add the header as a separate file with that exact name |
| Missing DHT / Adafruit library | Check libraries.txt is present and matches the supplied file; restart the simulation |
| Lamp is off at startup | Expected: select demo 1 or trigger the PIR in LIVE |
| Sensor changes have no effect | Return to LIVE; demos intentionally use fixed sample inputs |
| Vent does not change at 27°C | Expected hysteresis; use 32°C to open or 24°C to close |
| Demo button does not advance | Release between presses; keyboard D requires focus on the circuit |
| Countdown seems 12 seconds | The PIR's 2-second HIGH pulse comes before the 10-second hold in LIVE |
| Display says SENSOR CHECK | Check DHT power/data/10k pull-up and wait for its next 2-second reading |

## Presentation script (about one minute)

> “ROOM / IQ uses an ESP32 to combine motion, light and temperature sensing. In the first scenario, it is dark and someone moves in the room at 24 degrees. The lamp turns on and the vent stays shut. In the second scenario, it is bright and hot at 32 degrees. The lamp turns off and the vent opens. In the third scenario, motion stops. The countdown gives a ten-second grace period, then the lamp turns off. Fresh motion resets the timer. Different on and off thresholds prevent rapid switching, and the vent still responds to heat even when nobody is moving.”

For the objective, algorithm, limitations and viva questions, see [the mini-project report](docs/mini-project-report.md).

## Validation and developer commands

Run the control tests and wiring checks with:

```bash
bash tests/run.sh
```

This compiles the **same C++ controller used by the firmware**, exercises three full scenario timelines and edge cases, then checks the 23 required circuit connections. It is not an ESP32 hardware simulation. See [validation.md](docs/validation.md) for actual build/test results and runtime limitations.

The sketch supports the classic ESP32 using Arduino-ESP32 2.x or 3.x PWM APIs. The recorded build uses 2.0.17. For an optional local Arduino IDE build, put `sketch.ino` and `room_controller.h` in a sketch folder (rename the `.ino` to match that folder), install the ESP32 board package and the five versions in `libraries.txt`, then choose **ESP32 Dev Module**. Online Wokwi performs this build for the beginner workflow.
