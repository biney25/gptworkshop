#pragma once

// Hardware-independent rules. The ESP32 sketch and desktop tests use this file.
#include <stdint.h>
#include <math.h>

namespace room {
constexpr uint32_t HOLD_MS = 10000;  // Demo-friendly; try 60000 for a real room.
constexpr float DARK_LUX = 100.0f;
constexpr float BRIGHT_LUX = 150.0f;
constexpr float OPEN_C = 28.0f;
constexpr float CLOSE_C = 26.0f;

struct Inputs {
  float temperature;
  float lux;
  bool motion;
};

struct State {
  bool occupied = false;
  bool dark = false;
  bool lamp = false;
  bool ventOpen = false;
  bool sensorFault = false;
  uint32_t remainingMs = 0;
};

class Controller {
 public:
  void reset() {
    state_ = State{};
    seenMotion_ = false;
    lastMotion_ = 0;
  }

  const State& update(const Inputs& input, uint32_t now) {
    if (input.motion) {
      lastMotion_ = now;
      seenMotion_ = true;
    }
    // Unsigned subtraction also works when millis() wraps after ~49.7 days.
    const uint32_t elapsed = now - lastMotion_;
    if (seenMotion_ && elapsed >= HOLD_MS) seenMotion_ = false;
    state_.occupied = seenMotion_ && elapsed < HOLD_MS;
    state_.remainingMs = state_.occupied ? HOLD_MS - elapsed : 0;

    const bool lightOK = isfinite(input.lux) && input.lux >= 0;
    const bool temperatureOK = isfinite(input.temperature) &&
                               input.temperature >= -40 && input.temperature <= 80;
    state_.sensorFault = !lightOK || !temperatureOK;

    // Two thresholds keep sensor noise from making the lamp flicker.
    if (!lightOK || input.lux >= BRIGHT_LUX) state_.dark = false;
    else if (input.lux < DARK_LUX) state_.dark = true;
    state_.lamp = state_.occupied && state_.dark;

    // Ventilation is independent of occupancy. Unknown temperature opens it.
    if (!temperatureOK || input.temperature >= OPEN_C) state_.ventOpen = true;
    else if (input.temperature <= CLOSE_C) state_.ventOpen = false;
    return state_;
  }

 private:
  State state_;
  bool seenMotion_ = false;
  uint32_t lastMotion_ = 0;
};

enum class Mode : uint8_t { Live, DarkMotion, HotBright, Vacancy };

inline Inputs inputsForMode(Mode mode, uint32_t elapsed, const Inputs& live) {
  switch (mode) {
    case Mode::DarkMotion: return {24.0f, 20.0f, true};
    case Mode::HotBright: return {32.0f, 800.0f, true};
    // Seed a short motion event, then let the SAME controller expire naturally.
    case Mode::Vacancy: return {24.0f, 20.0f, elapsed < 1500};
    default: return live;
  }
}
}  // namespace room
