# ROOM / IQ: Smart lighting and automatic ventilation using ESP32

## Aim

Design a small room automation prototype that turns on a lamp only when the room is dark and recently occupied, and opens a ventilation flap when the room is hot. Demonstrate its behavior in Wokwi using three repeatable scenarios.

## Problem statement

Lights may be left on in empty or naturally bright rooms. A manually operated vent may stay closed as temperature rises. This project combines motion, ambient light and temperature inputs to automate those two decisions while keeping the circuit affordable and understandable.

## Hardware and roles

- **ESP32:** reads sensors and executes the rules.
- **LDR module:** estimates ambient illumination.
- **PIR sensor:** signals movement; the controller extends occupancy for a short hold period.
- **DHT22:** measures air temperature. Its humidity channel is not required by the project.
- **Yellow LED + 330Ω:** low-voltage model of the room lamp.
- **Servo:** rotates a model ventilation flap between 0° and 90°.
- **SSD1306 OLED:** makes sensor readings, decisions and timing visible.
- **Pushbutton:** chooses repeatable demonstration inputs or live sensors.

## Algorithm

1. Initialize GPIO, I²C display, DHT22 and 50Hz servo PWM. Start with the lamp off.
2. Read motion continuously. Average and smooth light samples every 50ms. Read temperature every 2 seconds.
3. In LIVE mode, use physical sensor readings. In a demo mode, use the selected sample readings through the same control function.
4. On every active motion reading, record the current time. Occupancy remains active for 10 seconds after the last HIGH reading.
5. Enter DARK below 100 lux and return to LIT at or above 150 lux. Preserve the previous decision between the two thresholds.
6. Turn the lamp on only if DARK and occupied; otherwise switch it off.
7. Open the vent at or above 28°C and close it at or below 26°C. Preserve its previous target between these values. This decision does not depend on motion.
8. Move the servo gradually toward its target. Update the OLED every 200ms and print serial status once a second or on output changes.
9. Repeat without waiting for the full occupancy timeout. Apply sensor-fault behavior if readings are unusable.

## Demonstration cases

| Case | Light | Motion | Temperature | Expected lamp | Expected vent |
|---|---|---|---|---|---|
| 1: Cool, occupied, dark | 20 lux | Present | 24°C | ON | SHUT |
| 2: Hot and bright | 800 lux | Present | 32°C | OFF | OPEN |
| 3: Person leaves | 20 lux | Stops | 24°C | ON during hold, OFF after 10s | SHUT |
| Additional: Empty but hot | 800 lux | None | 32°C | OFF | OPEN |
| Additional: Fresh motion | 20 lux | Re-triggered before expiry | 24°C | Remains ON; timer restarts | SHUT |

Expected results are design requirements; observed build and test results are recorded separately in [validation.md](validation.md). Complete the interactive Wokwi run before claiming all simulated hardware behavior is verified.

## Design choices

**Hysteresis:** two thresholds prevent chattering when a noisy input stays near the switching point. Example: after opening at 28°C, the vent stays open at 27°C and shuts only when temperature reaches 26°C or lower.

**Nonblocking timer:** a 10-second `delay()` would prevent the firmware from reacting to fresh motion, daylight, controls or heat. Tracking elapsed `millis()` keeps those functions responsive. The loop uses only a 5ms scheduling yield; sensor and display transactions have their own short execution time.

**Separate decisions:** lamp control combines occupancy and darkness. Vent control responds to temperature independently. Therefore, “no motion” does not incorrectly close a hot room's vent.

**Observability:** the screen distinguishes motion from the occupancy grace period and shows the exact readings used in demo mode. Serial logging provides a second way to verify the results.

## Limitations

- A PIR detects movement, not continuous presence. A motionless occupant can time out.
- Lux is an estimate using the Wokwi LDR model. Real sensors and ESP32 ADCs need calibration.
- A servo opening a flap is a model of ventilation. There is no simulated airflow, fan or automatic cooling model.
- The LED is a low-voltage lamp model. Driving a household lamp requires a different rated switching stage.
- These control decisions can avoid unnecessary lamp use, but electrical energy savings have not been measured.
- The controller stays awake; deep sleep is deliberately omitted to keep this project easy to demonstrate and responsive.

## Future scope

Use a calibrated digital light sensor, a presence sensor that can detect stationary occupants, a properly sized vent mechanism, and a measured low-power operating strategy. A network dashboard can be added later, but it is unnecessary for the three requested scenarios.

## Viva questions

**Why ESP32?** It provides analog input, digital GPIO, I²C and hardware PWM on one inexpensive board. Wi-Fi is available for future expansion but is not used here.

**Why does the lamp not turn on in a bright occupied room?** It requires both recent motion and darkness, avoiding unnecessary artificial light.

**What happens at 24°C?** The vent shuts because this is below its 26°C closing threshold. The lamp still depends on motion and light.

**What happens at 27°C?** The vent retains its previous target to avoid rapid switching near 28°C.

**When does the timeout start?** After the PIR output stops reporting motion. In this diagram the PIR HIGH pulse lasts 2 seconds; the firmware's 10-second hold starts after that pulse.

**Does repeated motion create many separate timers?** No. It updates one timestamp, extending the current occupancy window.

**Why is there no relay?** A yellow LED demonstrates the lamp state clearly while keeping the prototype simple and low voltage.

**Why use an OLED?** It exposes the controller's inputs and decisions, so the presentation does not depend on interpreting servo position or LED state alone.

**Are the demos cheating by forcing outputs?** No. They supply known input readings to the same controller used in LIVE mode. LIVE mode is still required to verify the wired sensor path.

**What happens if the DHT22 disconnects?** After six seconds without a valid reading, the vent opens and SENSOR CHECK appears. This is a conservative demo policy, not a certified safety function.
