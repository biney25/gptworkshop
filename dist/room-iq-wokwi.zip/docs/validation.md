# Validation record

Validated in the cloud workspace on 4 November 2026.

## Passed

- **Shared controller:** `bash tests/run.sh` compiled the controller with GCC, C++11, `-Wall -Wextra -Werror -pedantic`. **3,627 checks passed**, covering the three 12-second demo timelines, exact timeout expiry, retriggering, daylight during occupancy, threshold hysteresis, startup state, millis rollover, mode reset and sensor-fault recovery. The sketch includes this same `room_controller.h`.
- **Circuit checks:** all **23 required sensor, power, output and button connections** passed the local wiring validator. JSON parsing and unique part IDs also passed.
- **Official Wokwi diagram linter:** `wokwi-cli lint --offline /workspace/gptworkshop`, Wokwi CLI **0.29.1**, returned exit status **0**, with **0 errors, 0 warnings, 1 information message**. Its bundled catalog calls `board-esp32-devkit-c-v4` an undocumented type; the board is explicitly listed in Wokwi's diagram-format guide and its pin map was checked against the official `wokwi-boards` definition.
- **Real ESP32 compilation:** Arduino CLI **1.2.2**, Arduino-ESP32 **2.0.17**, classic **ESP32 Dev Module**, four compile jobs. The complete sketch and header compiled and linked with all five pinned libraries. Exit status **0**. **310,965 bytes flash (23%)**, **22,324 bytes static RAM (6%)**; 305,356 bytes of RAM remain before runtime allocation. The OLED's framebuffer is allocated at runtime, so these are build-time figures, not measured peak memory use.
- **Visual quick-start guide:** automated Chromium checks over a local HTTP server verified all four file tabs, exact clipboard contents, exact downloaded filenames/contents and keyboard tab navigation. Desktop **1440px** and mobile **390px** views had no horizontal overflow or JavaScript errors. The desktop layout was also inspected visually. These checks concern the guide, not Wokwi's simulation UI.

The cloud build used manually installed official Espressif archives, with the core and toolchain SHA-256 values verified against Espressif's package index. The CLI binary was checked against Arduino's release checksum list. Arduino CLI printed missing USB/mDNS/DFU discovery-helper messages; these do not prevent compilation. No physical-board upload was attempted. The build log is retained locally at `/workspace/.smartroom-tools/compile-final.log`.

## Not yet verified

- **Interactive Wokwi runtime:** no browser session for Wokwi or Wokwi CLI credential was available. No ESP32 simulation session was executed here. Therefore DHT transactions, ADC behavior, OLED pixels, servo animation and UI layout in the Wokwi browser still need the manual acceptance run below. Local C++ tests and successful compilation do not replace that run.
- **Physical hardware:** no board, wiring, current draw, lux calibration, servo mechanism or energy savings were measured.
- **Arduino-ESP32 3.x:** the sketch includes the 3.x PWM API path; the recorded real build exercises **2.0.17 only**.
- **Hosted project:** no Wokwi account project or public project URL was created. Saving the four files in the browser produces your own shareable project.

## Manual Wokwi acceptance run

1. Paste the four source files following README.md and press Play. Confirm `ROOM / IQ ready` and an updating OLED.
2. Press NEXT DEMO once. Confirm mode DEMO 1, 24.0°C, about 20 lux, LED ON, vent SHUT.
3. Press again. Confirm DEMO 2, 32.0°C, about 800 lux, LED OFF, vent OPEN and servo approximately 90°.
4. Press again. Confirm DEMO 3, LED ON during the initial motion and hold, a decreasing countdown, then OFF approximately 11.5 seconds after selection. Confirm vent SHUT.
5. Press again to return to LIVE. Trigger the PIR at the initial 20 lux / 24°C and confirm the lamp. Re-trigger during the hold and confirm it extends. Let it expire and confirm OFF.
6. While occupied in LIVE, raise light to 800 lux. Confirm lamp OFF after the smoothing settles. Return to 20 lux and trigger motion; confirm ON.
7. In LIVE, set DHT22 to 32°C and wait for a reading. Confirm OPEN. Stop motion and let occupancy expire; confirm it remains OPEN. Set 24°C and confirm SHUT.
8. Check the serial log and OLED agree. Save the Wokwi project, then use its Share control if you need a presentation link.

The ZIP and standalone visual guide are generated from the current source files with `python3 tools/package.py`, which verifies archive integrity and matching source contents.
