"""Generate the self-contained guide and ZIP, with the current Wokwi sources."""
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
source_names = ["sketch.ino", "diagram.json", "room_controller.h", "libraries.txt"]
sources = {name: (root / name).read_text() for name in source_names}
template = (root / "docs/guide.template.html").read_text()
payload = json.dumps(sources, ensure_ascii=True).replace("<", "\\u003c")
assert template.count("__PROJECT_FILES__") == 1
guide = template.replace("__PROJECT_FILES__", payload)
(root / "docs/start-here.html").write_text(guide)
(root / "dist").mkdir(exist_ok=True)
archive = root / "dist/room-iq-wokwi.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as package:
    for name in source_names + [
        ".gitignore", "README.md", "docs/start-here.html", "docs/guide.template.html", "docs/mini-project-report.md",
        "docs/validation.md", "tests/controller_test.cpp", "tests/check_diagram.py",
        "tests/run.sh", "tools/package.py",
    ]:
        package.write(root / name, name)
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    for name in source_names:
        assert package.read(name).decode() == sources[name]
print(f"Guide generated with {len(sources)} embedded source files")
print(f"ZIP verified: {archive} ({archive.stat().st_size:,} bytes)")
