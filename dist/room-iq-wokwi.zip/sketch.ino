/*
 * ROOM / IQ — ESP32 smart lighting + automatic ventilation
 * Wokwi: paste this file, room_controller.h, diagram.json and libraries.txt.
 * Press the blue button (or D) to cycle LIVE -> DEMO 1 -> 2 -> 3 -> LIVE.
 * Serial shortcuts: 1, 2, 3, L (live), ? (help).
 */
#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>
#include <esp_arduino_version.h>
#include "room_controller.h"

constexpr uint8_t LDR_PIN = 34;    // ADC1 input; sensor powered from 3.3 V.
constexpr uint8_t PIR_PIN = 14;
constexpr uint8_t DHT_PIN = 4;
constexpr uint8_t LAMP_PIN = 25;
constexpr uint8_t SERVO_PIN = 26;
constexpr uint8_t DEMO_PIN = 27;   // Button to GND, internal pull-up.
constexpr uint8_t SDA_PIN = 21;
constexpr uint8_t SCL_PIN = 22;
constexpr uint8_t SERVO_CHANNEL = 0;
constexpr uint8_t CLOSED_ANGLE = 0;
constexpr uint8_t OPEN_ANGLE = 90;

DHT dht(DHT_PIN, DHT22);
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
room::Controller controller;
room::Mode mode = room::Mode::Live;
room::Inputs liveInputs{NAN, NAN, false};
room::Inputs activeInputs{NAN, NAN, false};
room::State state;
bool oledOK = false;
bool haveTemperature = false;
bool haveLight = false;
bool buttonRaw = HIGH;
bool buttonStable = HIGH;
bool reportNow = true;
uint32_t modeSince = 0;
uint32_t buttonChanged = 0;
uint32_t lastDht = 0;
uint32_t lastGoodDht = 0;
uint32_t lastLight = 0;
uint32_t lastDisplay = 0;
uint32_t lastReport = 0;
uint32_t lastServo = 0;
float filteredAdc = 0;
int servoAngle = CLOSED_ANGLE;

// Direct hardware PWM avoids adding a servo-library dependency.
// This supports both ESP32 Arduino core 2.x and 3.x.
void writeServo(int angle) {
  const uint32_t pulseUs = 500 + (2000UL * angle) / 180;
  const uint32_t duty = (pulseUs * 65535UL) / 20000UL;
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(SERVO_PIN, duty);
#else
  ledcWrite(SERVO_CHANNEL, duty);
#endif
}

const char* modeName() {
  switch (mode) {
    case room::Mode::DarkMotion: return "DEMO 1";
    case room::Mode::HotBright: return "DEMO 2";
    case room::Mode::Vacancy: return "DEMO 3";
    default: return "LIVE";
  }
}

void selectMode(room::Mode selected, uint32_t now) {
  mode = selected;
  modeSince = now;
  controller.reset();  // Every demo starts from a repeatable state.
  reportNow = true;
  Serial.printf("\nMODE: %s%s\n", modeName(),
                mode == room::Mode::Live ? " (physical sensors)" : " (sample inputs)");
}

void readControls(uint32_t now) {
  const bool raw = digitalRead(DEMO_PIN);
  if (raw != buttonRaw) {
    buttonRaw = raw;
    buttonChanged = now;
  }
  if (now - buttonChanged >= 35 && raw != buttonStable) {
    buttonStable = raw;
    if (buttonStable == LOW) {
      const uint8_t next = (static_cast<uint8_t>(mode) + 1) % 4;
      selectMode(static_cast<room::Mode>(next), now);
    }
  }
  // Limit work per iteration so a busy serial input cannot starve the loop.
  for (int count = 0; count < 16 && Serial.available(); ++count) {
    const char key = Serial.read();
    if (key >= '1' && key <= '3')
      selectMode(static_cast<room::Mode>(key - '0'), now);
    else if (key == 'l' || key == 'L' || key == '0')
      selectMode(room::Mode::Live, now);
    else if (key == '?')
      Serial.println("1: dark/motion/24C | 2: bright/hot/32C | 3: vacancy timer | L: live sensors");
  }
}

void sampleLight() {
  uint32_t sum = 0;
  for (int i = 0; i < 8; ++i) sum += analogRead(LDR_PIN);
  const float sample = sum / 8.0f;
  filteredAdc = haveLight ? filteredAdc * 0.75f + sample * 0.25f : sample;
  haveLight = true;
  // Wokwi LDR module: 10k fixed resistor, RL10=50k, gamma=0.7.
  // Clamp endpoints so division by zero cannot produce an invalid reading.
  const float adc = constrain(filteredAdc, 1.0f, 4094.0f);
  const float resistance = 10000.0f * adc / (4095.0f - adc);
  liveInputs.lux = powf(50000.0f * powf(10.0f, 0.7f) / resistance, 1.0f / 0.7f);
}

void sampleTemperature(uint32_t now) {
  const float temperature = dht.readTemperature();
  if (isfinite(temperature) && temperature >= -40 && temperature <= 80) {
    liveInputs.temperature = temperature;
    lastGoodDht = now;
    haveTemperature = true;
  }
}

void readSensors(uint32_t now) {
  liveInputs.motion = digitalRead(PIR_PIN) == HIGH;
  if (now - lastLight >= 50) {
    lastLight = now;
    sampleLight();
  }
  if (now - lastDht >= 2000) {
    lastDht = now;
    sampleTemperature(now);
  }
  // A transient failed read keeps the last good value, but never indefinitely.
  if (!haveTemperature || now - lastGoodDht >= 6000) liveInputs.temperature = NAN;
}

void moveVent(uint32_t now) {
  const int target = state.ventOpen ? OPEN_ANGLE : CLOSED_ANGLE;
  if (now - lastServo < 20 || servoAngle == target) return;
  lastServo = now;
  servoAngle += target > servoAngle ? 3 : -3;
  if (abs(servoAngle - target) < 3) servoAngle = target;
  writeServo(servoAngle);
}

void drawLampIcon(int x, int y, bool on) {
  oled.drawCircle(x, y, 4, SSD1306_WHITE);
  if (on) oled.fillCircle(x, y, 2, SSD1306_WHITE);
  oled.drawFastHLine(x - 2, y + 5, 5, SSD1306_WHITE);
  oled.drawFastHLine(x - 1, y + 7, 3, SSD1306_WHITE);
}

void drawDisplay() {
  if (!oledOK) return;
  oled.clearDisplay();
  oled.setTextSize(1);
  oled.fillRect(0, 0, 128, 11, SSD1306_WHITE);
  oled.setTextColor(SSD1306_BLACK);
  oled.setCursor(3, 2);
  oled.print("ROOM / IQ");
  oled.setCursor(89, 2);
  oled.print(modeName());
  oled.setTextColor(SSD1306_WHITE);

  oled.setCursor(1, 15);
  oled.setTextSize(2);
  if (isfinite(activeInputs.temperature)) oled.print(activeInputs.temperature, 1);
  else oled.print("--.-");
  oled.setTextSize(1);
  oled.setCursor(51, 16);
  oled.print("C");
  oled.setCursor(76, 15);
  if (isfinite(activeInputs.lux)) {
    if (activeInputs.lux > 9999) oled.print("9999+");
    else oled.print(static_cast<int>(activeInputs.lux));
  } else oled.print("--");
  oled.setCursor(76, 25);
  oled.print(state.dark ? "lx DARK" : "lx LIT");

  oled.drawFastHLine(0, 35, 128, SSD1306_WHITE);
  drawLampIcon(6, 43, state.lamp);
  oled.setCursor(15, 40);
  oled.print(state.lamp ? "ON" : "OFF");
  oled.drawRect(62, 40, 10, 9, SSD1306_WHITE);
  if (state.ventOpen) oled.drawLine(63, 47, 70, 41, SSD1306_WHITE);
  else {
    oled.drawFastHLine(64, 43, 6, SSD1306_WHITE);
    oled.drawFastHLine(64, 46, 6, SSD1306_WHITE);
  }
  oled.setCursor(77, 40);
  oled.print(state.ventOpen ? "OPEN" : "SHUT");

  oled.setCursor(0, 54);
  if (state.sensorFault) oled.print("SENSOR CHECK");
  else if (activeInputs.motion) oled.print("MOTION DETECTED");
  else if (state.occupied) {
    oled.print("HOLD ");
    oled.print((state.remainingMs + 999) / 1000);
    oled.print("s");
    oled.drawRect(63, 54, 64, 7, SSD1306_WHITE);
    oled.fillRect(64, 55, (state.remainingMs * 62UL) / room::HOLD_MS, 5, SSD1306_WHITE);
  } else oled.print("EMPTY / SAVING ENERGY");
  oled.display();
}

void reportState(uint32_t now) {
  static bool previousLamp = false;
  static bool previousVent = false;
  const bool changed = previousLamp != state.lamp || previousVent != state.ventOpen;
  if (!reportNow && !changed && now - lastReport < 1000) return;
  reportNow = false;
  previousLamp = state.lamp;
  previousVent = state.ventOpen;
  lastReport = now;
  Serial.printf("[%s] T=%.1fC light=%.0flx motion=%d occupied=%d lamp=%s vent=%s hold=%lus%s\n",
                modeName(), activeInputs.temperature, activeInputs.lux,
                activeInputs.motion, state.occupied, state.lamp ? "ON" : "OFF",
                state.ventOpen ? "OPEN" : "SHUT",
                static_cast<unsigned long>((state.remainingMs + 999) / 1000),
                state.sensorFault ? " SENSOR_FAULT" : "");
}

void setup() {
  Serial.begin(115200);
  pinMode(LAMP_PIN, OUTPUT);
  digitalWrite(LAMP_PIN, LOW);
  pinMode(PIR_PIN, INPUT);
  pinMode(DEMO_PIN, INPUT_PULLUP);
  analogReadResolution(12);
  analogSetPinAttenuation(LDR_PIN, ADC_11db);
  dht.begin();
  Wire.begin(SDA_PIN, SCL_PIN);
  oledOK = oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  if (oledOK) oled.setTextWrap(false);
  else Serial.println("OLED unavailable: control and serial monitor still work.");
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  const bool pwmOK = ledcAttach(SERVO_PIN, 50, 16);
  if (!pwmOK) Serial.println("ERROR: servo PWM could not attach.");
#else
  ledcSetup(SERVO_CHANNEL, 50, 16);
  ledcAttachPin(SERVO_PIN, SERVO_CHANNEL);
#endif
  writeServo(CLOSED_ANGLE);
  sampleLight();
  sampleTemperature(millis());
  lastDht = millis();
  Serial.println("\nROOM / IQ ready. Button/D: next demo. Serial: 1, 2, 3, L, ?");
  Serial.println("Lamp: dark + recent motion. Vent: opens >=28C, shuts <=26C.");
}

void loop() {
  const uint32_t now = millis();
  readControls(now);
  readSensors(now);
  activeInputs = room::inputsForMode(mode, now - modeSince, liveInputs);
  state = controller.update(activeInputs, now);
  digitalWrite(LAMP_PIN, state.lamp ? HIGH : LOW);
  moveVent(now);
  if (now - lastDisplay >= 200) {
    lastDisplay = now;
    drawDisplay();
  }
  reportState(now);
  delay(5);  // Yield to the ESP32 scheduler; the timeout never blocks the loop.
}
