#include "../room_controller.h"
#include <iostream>
#include <limits>
#include <cstdlib>

int checks = 0;
void check(bool condition, const char* message) {
  ++checks;
  if (!condition) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(1);
  }
}

int main() {
  using namespace room;
  Controller c;
  auto s = c.update({24, 20, false}, 0);
  check(!s.lamp && !s.ventOpen && !s.occupied, "boot in a dark empty room stays off/shut");
  s = c.update({24, 20, true}, 0);
  check(s.lamp && !s.ventOpen && s.remainingMs == HOLD_MS, "scenario 1: dark/motion/24C");
  s = c.update({24, 20, false}, HOLD_MS - 1);
  check(s.lamp && s.remainingMs == 1, "lamp holds until the exact deadline");
  s = c.update({24, 20, false}, HOLD_MS);
  check(!s.lamp && !s.occupied && s.remainingMs == 0, "scenario 3: off at timeout");
  s = c.update({24, 20, false}, 0);
  check(!s.lamp, "expired motion never resurrects after clock wrap");

  c.reset();
  s = c.update({32, 800, true}, 100);
  check(!s.lamp && s.ventOpen, "scenario 2: hot/bright opens vent and lamp stays off");
  s = c.update({32, 800, false}, 10100);
  check(!s.lamp && s.ventOpen && !s.occupied, "empty hot room keeps ventilating");
  s = c.update({24, 800, false}, 10200);
  check(!s.ventOpen, "cooling closes vent even without motion");

  c.reset();
  c.update({24, 20, true}, 100);
  c.update({24, 20, true}, 9000);
  s = c.update({24, 20, false}, 10100);
  check(s.lamp && s.remainingMs == 8900, "fresh motion extends hold instead of old timer expiring");
  s = c.update({24, 800, false}, 10200);
  check(!s.lamp && s.occupied, "daylight turns lamp off immediately during occupancy hold");
  s = c.update({24, 20, false}, 10300);
  check(s.lamp, "darkness restores light while occupancy hold remains");

  c.reset();
  s = c.update({27, 120, true}, 1);
  check(!s.lamp && !s.ventOpen, "boot in hysteresis bands uses off/shut state");
  s = c.update({28, 99, true}, 2);
  check(s.lamp && s.ventOpen, "lower light threshold and upper temperature threshold");
  s = c.update({27, 149, true}, 3);
  check(s.lamp && s.ventOpen, "hysteresis avoids chatter in both bands");
  s = c.update({26, 150, true}, 4);
  check(!s.lamp && !s.ventOpen, "exact bright and close boundaries switch states");
  s = c.update({27, 100, true}, 5);
  check(!s.lamp && !s.ventOpen, "stays off/shut until activation thresholds crossed");

  c.reset();
  c.update({24, 20, true}, 0xfffffff0u);
  s = c.update({24, 20, false}, 0x10u);
  check(s.lamp && s.remainingMs == HOLD_MS - 32, "hold survives millis overflow");
  s = c.update({24, 20, false}, 0x2700u);
  check(!s.lamp, "wrapped clock still expires normally");

  const float nan = std::numeric_limits<float>::quiet_NaN();
  s = c.update({nan, 20, true}, 12000);
  check(s.sensorFault && s.ventOpen && s.lamp, "missing temperature opens vent without disabling lighting");
  s = c.update({24, nan, true}, 12001);
  check(s.sensorFault && !s.lamp && !s.ventOpen, "invalid light turns lamp off; temperature still works");
  s = c.update({100, -1, true}, 12002);
  check(s.sensorFault && !s.lamp && s.ventOpen, "out-of-range inputs are handled explicitly");
  s = c.update({24, 20, true}, 12003);
  check(!s.sensorFault && s.lamp && !s.ventOpen, "valid sensors recover automatically");

  Inputs live{25, 400, false};
  auto input = inputsForMode(Mode::Live, 100, live);
  check(input.temperature == 25 && input.lux == 400 && !input.motion, "live mode forwards actual sensors");
  for (const Mode mode : {Mode::DarkMotion, Mode::HotBright, Mode::Vacancy}) {
    c.reset();
    for (uint32_t t = 0; t <= 12000; t += 10) {
      input = inputsForMode(mode, t, live);
      s = c.update(input, t);
      if (mode == Mode::DarkMotion) check(s.lamp && !s.ventOpen, "demo 1 throughout timeline");
      if (mode == Mode::HotBright) check(!s.lamp && s.ventOpen, "demo 2 throughout timeline");
      if (mode == Mode::Vacancy) {
        check(s.lamp == (t < 11490) && !s.ventOpen, "demo 3 lights then times out through real rules");
      }
    }
  }
  c.reset();
  s = c.update(live, 0);
  check(!s.occupied && !s.lamp, "mode reset clears demo occupancy before going live");
  std::cout << "PASS: " << checks << " checks (three scenario timelines + control edge cases)\n";
}
