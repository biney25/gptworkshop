"""Check actual connections needed by this sketch, not just JSON syntax."""
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
diagram = json.loads((root / "diagram.json").read_text())
parts = {p["id"]: p for p in diagram["parts"]}
assert len(parts) == len(diagram["parts"]), "Duplicate part ID"
edges = {frozenset(c[:2]) for c in diagram["connections"]}
required = [
    ("ldr:AO", "esp:34"), ("ldr:VCC", "esp:3V3"),
    ("ldr:GND", "esp:GND.1"), ("dht:SDA", "esp:4"),
    ("dht:VCC", "esp:3V3"), ("dht:GND", "esp:GND.1"),
    ("pullup:1", "esp:3V3"), ("pullup:2", "dht:SDA"),
    ("pir:OUT", "esp:14"), ("pir:VCC", "esp:5V"),
    ("pir:GND", "esp:GND.1"), ("oled:SDA", "esp:21"),
    ("oled:SCL", "esp:22"), ("oled:VCC", "esp:3V3"),
    ("oled:GND", "esp:GND.2"), ("esp:25", "lampR:1"),
    ("lampR:2", "lamp:A"), ("lamp:C", "esp:GND.3"),
    ("vent:PWM", "esp:26"), ("vent:V+", "esp:5V"),
    ("vent:GND", "esp:GND.3"), ("demo:1.l", "esp:27"),
    ("demo:2.r", "esp:GND.3"),
]
for a, b in required:
    assert frozenset((a, b)) in edges, f"Missing wire {a} -> {b}"
for a, b, *_ in diagram["connections"]:
    assert a.split(":")[0] in parts or a.startswith("$serialMonitor:")
    assert b.split(":")[0] in parts or b.startswith("$serialMonitor:")
assert parts["lampR"]["attrs"]["value"] == "330"
assert parts["dht"]["attrs"]["temperature"] == "24"
assert parts["ldr"]["attrs"]["lux"] == "20"
assert parts["esp"]["type"] == "board-esp32-devkit-c-v4"
print(f"PASS: diagram structure and {len(required)} required wiring connections")
