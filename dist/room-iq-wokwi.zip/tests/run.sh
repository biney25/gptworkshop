#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build
g++ -std=c++11 -Wall -Wextra -Werror -pedantic tests/controller_test.cpp -o build/controller-test
./build/controller-test
python3 tests/check_diagram.py
